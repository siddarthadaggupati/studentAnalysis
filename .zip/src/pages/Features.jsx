import React from 'react'
import  Navbar  from '../components/Navbar.jsx'

const Features = () => {
  return (
    <div id='features' smooth>
      <Navbar/>
          <div style={{marginLeft:'15px',marginTop:'10px', marginRight:'10px'}}>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ad fugiat laudantium accusamus eaque officiis ipsa? Odit sunt maxime enim voluptatibus voluptatem doloremque recusandae inventore cupiditate. Deserunt blanditiis accusantium quaerat.
    Dolore sit quam corrupti ut minima beatae sunt animi reprehenderit quasi, corporis eligendi aperiam totam veniam velit ex minus error libero modi praesentium harum nam? Ut rem architecto magnam dolore?
    Aspernatur earum fugiat odit amet ipsum sequi, veritatis quae aliquam tempore <br /> <br /> voluptates modi unde saepe corrupti eaque aliquid delectus quod, eveniet harum eligendi minus facilis sunt quos. Necessitatibus, velit incidunt!
    Provident, reiciendis eveniet odit eum quos libero excepturi soluta harum sunt quaerat vel hic pariatur architecto maiores quibusdam incidunt voluptatum voluptatem culpa recusandae nam delectus nisi laborum. Optio, doloremque nam!
    Quaerat nam soluta dolore rerum ipsam fugit numquam aut sequi necessitatibus accusantium vero facilis aperiam saepe ut, cupiditate qui similique nisi explicabo nobis unde voluptatum quidem dicta! Numquam, deserunt hic.
    Minus officiis eos quasi laborum modi sunt vitae voluptates aspernatur, labore laudantium quas nemo suscipit hic! Cum, laborum vel repudiandae nam facere, nisi alias tempora similique illum porro, repellendus eligendi?
    Recusandae accusantium beatae dicta consequuntur cum facere tempora iure voluptates velit adipisci odit, tempore eos nihil, aut necessitatibus debitis dolorem aliquid nesciunt saepe quibusdam porro repudiandae quod. Praesentium, odio sint?
    Pariatur autem nam delectus beatae inventore cupiditate rem odit sint commodi enim dolorem cumque quibusdam <br /><br /> impedit, voluptatibus explicabo! Harum quibusdam id, quae delectus ipsam blanditiis nam eos iusto explicabo itaque.
    Ea assumenda doloribus incidunt? Quos architecto consectetur non eos provident assumenda incidunt dolorum, placeat laboriosam laudantium eaque unde qui voluptatum cum? Sunt nostrum recusandae ipsam, soluta qui labore esse dolores.
    Molestias incidunt ratione suscipit, quidem qui natus quos labore provident cumque, obcaecati, dicta neque ad minus dignissimos mollitia ab? Quo iste officiis nemo, pariatur corrupti libero quas odit optio delectus!
    Sed unde ratione quaerat deleniti fugiat eaque <br /> <br /> saepe animi id itaque, molestiae cumque. Sequi adipisci ab dolorem numquam ipsum porro minus, saepe iusto quam odio asperiores corrupti dolore debitis illo.
    Laudantium magni mollitia esse veniam placeat vitae eius itaque nihil, atque cum odio, accusantium suscipit voluptatum autem. Modi reprehenderit iusto incidunt recusandae omnis soluta earum aut error accusantium sequi! Accusantium!
    Atque velit fuga sint molestiae in ipsam illo ex quo nulla temporibus facilis voluptatibus, ut esse unde nesciunt similique, quibusdam repellat non recusandae a ipsum fugiat quaerat. Earum, deleniti ad.
    Eaque dolorum magnam eius id atque, dignissimos eligendi possimus quod consequatur expedita corrupti odio sint amet voluptatem optio, voluptate debitis pariatur nemo illo omnis quos asperiores sequi ab! Facere, quasi!
    Veniam rerum iste provident autem hic doloribus eligendi vitae odit sapiente in perspiciatis distinctio corrupti ut et quo quam fugit recusandae eos suscipit modi, delectus, magnam exercitationem doloremque. Excepturi, accusamus
  </div>
    </div>
  )
}

export default Features